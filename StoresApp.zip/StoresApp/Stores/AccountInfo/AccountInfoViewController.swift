//
//  AccountInfoViewController.swift
//  Stores
//
//  Created by Student on 12/6/24.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase

class AccountInfoViewController: UIViewController {
    
    
    @IBOutlet weak var profileName: UILabel!
    
    @IBOutlet weak var userEmail: UILabel!
    

    @IBOutlet weak var logoutButton: UIButton!
    
    override func viewDidLoad() {
            super.viewDidLoad()

            self.title = "Account Info"
            
            loadUserInfo()
        }

       
        func loadUserInfo() {
            
            guard let currentUser = Auth.auth().currentUser else {
                
                print("No user is logged in.")
                return
            }

            
            let userDBRef = Database.database().reference().child("Users").child(currentUser.uid)
            userDBRef.observeSingleEvent(of: .value, with: { snapshot in
                guard let userData = snapshot.value as? [String: Any] else {
                    print("Failed to fetch user data.")
                    return
                }

                
                if let profileName = userData["profileName"] as? String,
                   let email = userData["email"] as? String {
                    
                    
                    DispatchQueue.main.async {
                        self.profileName.text = profileName
                        self.userEmail.text = email
                    }

                    //print("Profile Name: \(profileName)")
                    //print("Email: \(email)")
                }
            })
        }
    
    
    @IBAction func logoutTapped(_ sender: Any) {
        
        guard let currentUser = Auth.auth().currentUser else {
                //print("No user is logged in.")
                return
            }
            
            //print("User \(currentUser.email ?? "Unknown") is logged in.")
            
            
            UserModel.shared.offlineUser(uid: currentUser.uid)
            
            do {
                try Auth.auth().signOut()
                //print("User signed out successfully.")
                
                let alert = UIAlertController(title: "Logged Out", message: "You have been logged out successfully.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                    
                    if let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate {
                        
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        if let loginVC = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController {
                            let navController = UINavigationController(rootViewController: loginVC)
                            
                            sceneDelegate.window?.rootViewController = navController
                            sceneDelegate.window?.makeKeyAndVisible()
                            
                        } else {
                            print("Error with LoginViewController")
                        }
                    } else {
                        print("SceneDelegate not found.")
                    }
                }))
                
                self.present(alert, animated: true, completion: nil)
                
            } catch {
                print("Error signing out: \(error.localizedDescription)")
            }
    }
    
}
