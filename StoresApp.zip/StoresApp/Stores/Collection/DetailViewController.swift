//
//  DetailViewController.swift
//  Stores
//
//  Created by Student on 11/25/24.
//

import UIKit
import FirebaseAuth
import FirebaseDatabaseInternal

class DetailViewController: UIViewController {
    
    var store: Store?
    var storeLogo: UIImage?
    
    @IBOutlet weak var storeName: UILabel!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var storeImage: UIImageView!
    @IBOutlet weak var hours: UILabel!
    @IBOutlet weak var favoriteSwitch: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let store = store {
            storeName.text = store.name
            address.text = store.address
            hours.text = store.hours
            storeImage.image = storeLogo ?? UIImage(named: "genericStoreLogo")
            
            // Check if the store is already a favorite
            checkIfStoreIsFavorite(store: store)
        }
    }

    // MARK: - Check if store is a favorite
    func checkIfStoreIsFavorite(store: Store) {
        guard let user = Auth.auth().currentUser else { return }
        
        let ref = Database.database().reference().child("Users").child(user.uid).child("favorites")
        
        ref.observe(.value) { snapshot in
            if let favorites = snapshot.value as? [String: Bool] {
                self.favoriteSwitch.isOn = favorites[store.name] ?? false
            } else {
                self.favoriteSwitch.isOn = false
            }
        }
    }

    // MARK: - Toggle favorite status when the UISwitch changes
    @IBAction func favoriteToggle(_ sender: UISwitch) {
        guard let user = Auth.auth().currentUser, let store = store else { return }
        
        let ref = Database.database().reference().child("Users").child(user.uid).child("favorites")
        
        if sender.isOn {
            // Switch is ON, add the store to favorites
            ref.updateChildValues([store.name: true]) { error, _ in
                if let error = error {
                    print("Error adding store to favorites: \(error.localizedDescription)")
                } else {
                    print("Successfully added store to favorites.")
                    // Refresh the favorite status UI immediately
                    self.checkIfStoreIsFavorite(store: store)
                }
            }
        } else {
            // Switch is OFF, remove the store from favorites
            ref.child(store.name).removeValue { error, _ in
                if let error = error {
                    print("Error removing store from favorites: \(error.localizedDescription)")
                } else {
                    print("Successfully removed store from favorites.")
                    // Refresh the favorite status UI immediately
                    self.checkIfStoreIsFavorite(store: store)
                }
            }
        }
    }
}
