//
//  StoreCollectionViewCell.swift
//  Stores
//
//  Created by Student on 11/25/24.
//

import UIKit

class StoreCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var storeName: UILabel!
    @IBOutlet weak var storeImage: UIImageView!
    
    override func awakeFromNib() {
            super.awakeFromNib()
            
        storeName.numberOfLines = 4
        storeImage.contentMode = .scaleAspectFill
                
                
        storeImage.translatesAutoresizingMaskIntoConstraints = false
        storeImage.heightAnchor.constraint(equalToConstant: 150).isActive = true
        storeImage.widthAnchor.constraint(equalToConstant: 150).isActive = true
        
    }
    
    
}
