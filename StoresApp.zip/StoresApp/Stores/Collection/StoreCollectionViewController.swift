//
//  StoreCollectionViewController.swift
//  Stores
//
//  Created by Student on 11/25/24.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth

class StoreCollectionViewController: UICollectionViewController {
    
    var myStores: [Store] = []
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Stores"
       
        self.navigationItem.hidesBackButton = true
            
            
        let logoutButton = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(logoutTapped))
        self.navigationItem.leftBarButtonItem = logoutButton
        
        
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
                   
                    layout.minimumInteritemSpacing = 10
                    layout.minimumLineSpacing = 10

                    let numberOfItemsPerRow: CGFloat = 2
                    let padding: CGFloat = 10
                    let availableWidth = collectionView.frame.width - (padding * (numberOfItemsPerRow + 1))
                    let itemWidth = availableWidth / numberOfItemsPerRow
                    
                    
                    layout.itemSize = CGSize(width: itemWidth, height: itemWidth)
            
                }
        
        
        let storeDBref = Database.database().reference().child("stores")
        
        storeDBref.getData { [weak self] error, snapshot in
            if let error = error {
                print("Error fetching data: \(error.localizedDescription)")
                return
            }
            
            if let snapshot = snapshot, snapshot.exists(), let data = snapshot.value as? [String: Any] {
                var tempStores: [Store] = []
                
                for child in snapshot.children {
                    if let data = child as? DataSnapshot {
                        
                        if let aStore = Store(snapshot: data) {
                            tempStores.append(aStore)
                        } else {
                            print("Cannot parse Store: \(data)")
                        }
                    }
                }
                
                self?.myStores = tempStores
                self?.collectionView.reloadData()
            } else {
                print("No data found.")
            }
        }
        
    }
    
    
        
        @objc func logoutTapped() {
            
            do {
                try Auth.auth().signOut()

                if let loginVC = self.navigationController?.viewControllers.first(where: { $0 is LoginViewController }) as? LoginViewController {
                    self.navigationController?.popToViewController(loginVC, animated: true)
                }
            } catch let signOutError as NSError {
                print("Error signing out: %@", signOutError)
            }
        }
    
    
    
    // MARK: - UICollectionView DataSource
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return myStores.count
    }
    
    
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionCell", for: indexPath) as! StoreCollectionViewCell
        
        let store = myStores[indexPath.item]
        
        cell.storeImage.image = getImage(for: store)
        cell.storeName.text = store.name

        adjustLabelToFiveLines(for: store, in: cell)
        
        return cell
    }
    
 
    func getImage(for store: Store) -> UIImage {
        
        let genericImage = UIImage(named: "genericStoreLogo") ?? UIImage()
        
        var storeName = store.name.lowercased()
        storeName = storeName.replacingOccurrences(of: "’", with: "")
        
        
        if let storeImage = UIImage(named: storeName) {
            
            let resizedImage = storeImage.scalePreservingAspectRatio(targetSize: CGSize(width: 180.0, height: 180.0))
            return resizedImage
        }
        

        return genericImage
    }
    
    func adjustLabelToFiveLines(for store: Store, in cell: StoreCollectionViewCell) {
        
        guard let label = cell.storeName else {
            return
        }

        label.numberOfLines = 5

        let requiredHeight: CGFloat = 5 * label.font.lineHeight

        let storeNameHeight = calculateLabelHeight(for: store.name)

        let padding: CGFloat = requiredHeight - storeNameHeight

        if padding > 0 {
            
            label.frame = CGRect(x: label.frame.origin.x, y: label.frame.origin.y, width: label.frame.size.width, height: requiredHeight)
            
            label.text = store.name + "\n" + String(repeating: "\n", count: Int(padding / label.font.lineHeight))
        } else {
            
            label.frame = CGRect(x: label.frame.origin.x, y: label.frame.origin.y, width: label.frame.size.width, height: storeNameHeight)
        }
 
    }
 
    func calculateLabelWidth(for word: String, in label: UILabel) -> CGFloat {
        let maxSize = CGSize(width: label.frame.width, height: .infinity)
        let boundingBox = word.boundingRect(with: maxSize, options: .usesLineFragmentOrigin, attributes: [.font: label.font!], context: nil)
        return boundingBox.width
    }

   
    
    func calculateLabelHeight(for storeName: String) -> CGFloat {
        let font = UIFont.preferredFont(forTextStyle: .body)
        let maxWidth = collectionView.frame.width / 2 - 20 // Padding and image space
        let maxSize = CGSize(width: maxWidth, height: .infinity)
        let boundingBox = storeName.boundingRect(with: maxSize, options: .usesLineFragmentOrigin, attributes: [.font: font], context: nil)
        return boundingBox.height
    }
    
 
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let selectedStore = myStores[indexPath.item]
        
        
        performSegue(withIdentifier: "showDetailSegue", sender: selectedStore)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetailSegue" {
            if let detailsVC = segue.destination as? DetailViewController,
               let selectedStore = sender as? Store {
                
                let storeImage = getImage(for: selectedStore)
                
                detailsVC.store = selectedStore
                detailsVC.storeLogo = storeImage
            }
        }
    }
    
        
        // MARK: UICollectionViewDelegateFlowLayout (for layout adjustments)
        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            let itemWidth = (collectionView.frame.width - 30) / 2
            let itemHeight: CGFloat = 180
            return CGSize(width: itemWidth, height: itemHeight)
        }
        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
            return 1.0
        }
        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
            return 5
        }
    
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
            return UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        }
    
}


