//
//  FavoritesViewController.swift
//  Stores
//
//  Created by Student on 11/25/24.
//

import UIKit
import FirebaseAuth
import FirebaseDatabaseInternal

class FavoritesViewController: UITableViewController {

    var favoriteStoreNames: [String] = []
    var favoriteStores: [Store] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        checkUserAuthentication()
    }

    func checkUserAuthentication() {
        if let user = Auth.auth().currentUser {
            print("User is signed in: \(user.uid)")
            fetchFavoriteStores()
        } else {
            print("No user is signed in.")
        }
    }

    func fetchFavoriteStores() {
        guard let user = Auth.auth().currentUser else { return }
        
        let ref = Database.database().reference().child("Users").child(user.uid).child("favorites")
        
        ref.observe(.value) { snapshot in
            if let favorites = snapshot.value as? [String: Bool] {
                self.favoriteStoreNames = Array(favorites.keys)
                self.fetchStoreDetails()
            } else {
                self.favoriteStoreNames = []
                self.favoriteStores = []
                self.tableView.reloadData()
            }
        }
    }

    func fetchStoreDetails() {
        var stores: [Store] = []

        for storeName in favoriteStoreNames {
            if let store = StoreModel.shared.postedStores.first(where: { $0.name == storeName }) {
                stores.append(store)
            } else {
                Task {
                    do {
                        if let store = try await StoreModel.shared.fetchStore(byID: storeName) {
                            stores.append(store)
                        }
                    } catch {
                        print("Error fetching store details: \(error.localizedDescription)")
                    }
                }
            }
        }

        self.favoriteStores = stores.sorted { $0.name.lowercased() < $1.name.lowercased() }

        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }

    // MARK: - UITableView Data Source Methods
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return favoriteStores.isEmpty ? 1 : favoriteStores.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "favoritesCell", for: indexPath) as! FavoriteTableViewCell
        
        if favoriteStores.isEmpty {
            cell.name?.text = "No favorites"
            cell.logo?.image = nil
        } else {
            let store = favoriteStores[indexPath.row]
            cell.name?.text = store.name
            cell.logo?.image = StoreModel.shared.getImage(for: store)
        }
        
        return cell
    }

    // MARK: - UITableView Delegate Methods
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if !favoriteStores.isEmpty {
            let selectedStore = favoriteStores[indexPath.row]
            performSegue(withIdentifier: "showDetailSegue", sender: selectedStore)
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetailSegue" {
            if let detailsVC = segue.destination as? DetailViewController,
               let selectedStore = sender as? Store {

                let storeImage = StoreModel.shared.getImage(for: selectedStore)
                detailsVC.store = selectedStore
                detailsVC.storeLogo = storeImage
            }
        }
    }

    // MARK: - Deletion Logic
    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let storeToDelete = favoriteStores[indexPath.row]
        
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { [weak self] (action, view, completionHandler) in
            self?.deleteFavoriteStore(store: storeToDelete, at: indexPath)
            completionHandler(true)
        }

        let swipeActionsConfig = UISwipeActionsConfiguration(actions: [deleteAction])
        swipeActionsConfig.performsFirstActionWithFullSwipe = true
        return swipeActionsConfig
    }

    func deleteFavoriteStore(store: Store, at indexPath: IndexPath) {
        guard let user = Auth.auth().currentUser else { return }

        let ref = Database.database().reference().child("Users").child(user.uid).child("favorites")

        ref.child(store.name).removeValue { [weak self] error, _ in
            if let error = error {
                print("Error removing store from favorites: \(error.localizedDescription)")
                return
            }

            print("Successfully removed store from favorites.")
            
            self?.fetchFavoriteStores()
        }
    }

    deinit {
        if let user = Auth.auth().currentUser {
            let ref = Database.database().reference().child("Users").child(user.uid).child("favorites")
            ref.removeAllObservers()
        }
    }
}
