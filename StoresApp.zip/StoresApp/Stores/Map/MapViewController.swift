//
//  MapViewController.swift
//  Stores
//
//  Created by Student on 11/25/24.
//

import UIKit
import CoreLocation
import MapKit
import Firebase
import FirebaseDatabase

class MapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    @IBOutlet weak var myMap: MKMapView!
    
    let locationManager = CLLocationManager()
    let storeModel = StoreModel.shared
    var stores: [Store] = []
    var storeAnnotations: [StoreAnnotation] = []
    var selectedStoreId: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        locationManager.requestWhenInUseAuthorization()
        myMap.showsUserLocation = true
        myMap.delegate = self
        
        
        observeStores()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        checkLocationServices()
        myMap.mapType = .standard
        zoomToJacksonNJ()
        addStoreAnnotations()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        locationManager.stopUpdatingLocation()
    }
    
    // MARK: - Location Related Methods
    
    func zoomToJacksonNJ() {
        let jacksonNJ = CLLocationCoordinate2D(latitude: 40.16170150712161, longitude: -74.41734654663740)
        
        let region = MKCoordinateRegion(center: jacksonNJ, latitudinalMeters: 500, longitudinalMeters: 500)
        myMap.setRegion(region, animated: true)
    }
    
    func checkLocationServices() {
        if CLLocationManager.locationServicesEnabled() {
            setupLocationManager()
            checkLocationAuthorization()
        }
    }
    
    func setupLocationManager() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
    }
    
    func checkLocationAuthorization() {
        switch locationManager.authorizationStatus {
        case .authorizedWhenInUse:
            locationManager.startUpdatingLocation()
        case .denied:
            print("Location access denied")
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .restricted:
            print("Location access restricted")
        case .authorizedAlways:
            break
        default:
            print("Location authorization status unknown")
        }
    }
    
    // MARK: - Firebase Store Data Integration
    
    func observeStores() {
        
        storeModel.observeStores()
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(updateStores), name: StoreModel.shared.storesNotification, object: nil)
    }
    
    @objc func updateStores() {
        stores = storeModel.postedStores
        addStoreAnnotations()
    }
    
    // MARK: - Map Related Methods
    
    func addStoreAnnotations() {
        
        myMap.removeAnnotations(myMap.annotations)
        storeAnnotations.removeAll()
        
        for store in stores {
            //print("Store location: \(store.name), \(store.latitude), \(store.longitude)")
            
            let logoName = storeModel.getLogoName(for: store)
            let annotation = StoreAnnotation(
                latitude: store.latitude,
                longitude: store.longitude,
                title: store.name,
                subtitle: store.address,
                logo: logoName,
                store: store
            )
            
            //print(annotation.title)
            storeAnnotations.append(annotation)
            
        }
        //print(storeAnnotations)
        
        myMap.addAnnotations(storeAnnotations)
    }
    
    
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {

        guard !(annotation is MKUserLocation) else { return nil }
        
        guard let storeAnnotation = annotation as? StoreAnnotation else { return nil }
        
        let identifier = "StoreAnnotation"
        
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
        if annotationView == nil {
            annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: identifier)
        } else {
            annotationView?.annotation = annotation
        }
        
        annotationView?.canShowCallout = true
        annotationView?.calloutOffset = CGPoint(x: -5.0, y: 5.0)
        
        if let store = storeAnnotation.store {
            let storeLogoImage = storeModel.getImage(for: store)
            
            let resizedImage = storeLogoImage.scalePreservingAspectRatio(targetSize: CGSize(width: 60, height: 60))
            annotationView?.image = resizedImage
        } else {
            
            annotationView?.image = UIImage(systemName: "bag")?.scalePreservingAspectRatio(targetSize: CGSize(width: 30, height: 30))
        }
        
        let logoButton = UIButton(frame: CGRect(origin: CGPoint.zero, size: CGSize(width: 60.0, height: 60.0)))
        
        if let store = storeAnnotation.store {
            let logoImage = storeModel.getImage(for: store)
            logoButton.setImage(logoImage, for: .normal)
            
        }
        annotationView?.leftCalloutAccessoryView = logoButton
        
        
        let mapButton = UIButton(frame: CGRect(origin: CGPoint.zero, size: CGSize(width: 60.0, height: 60.0)))
        mapButton.setBackgroundImage(UIImage(systemName: "car"), for: .normal)
        annotationView?.rightCalloutAccessoryView = mapButton
        
        return annotationView
    }
    
    
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        guard let storeAnnotation = view.annotation as? StoreAnnotation else { return }
        
        if view.rightCalloutAccessoryView == control {
           
            let launchOptions = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]
            storeAnnotation.mapItem().openInMaps(launchOptions: launchOptions)
        } else if view.leftCalloutAccessoryView == control {
            
            if let storeTitle = storeAnnotation.title {
                
                performSegue(withIdentifier: "showDetailSegue", sender: storeTitle)
            }
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetailSegue" {
            if let detailsVC = segue.destination as? DetailViewController,
               let selectedStoreTitle = sender as? String {
                
                if let selectedStore = stores.first(where: { $0.name == selectedStoreTitle }) {
                    let storeImage = storeModel.getImage(for: selectedStore)
                    
                    detailsVC.store = selectedStore
                    detailsVC.storeLogo = storeImage
                }
            }
        }
    }
    
    deinit {
        
        NotificationCenter.default.removeObserver(self)
    }
}
