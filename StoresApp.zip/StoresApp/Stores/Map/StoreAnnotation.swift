//
//  StoreAnnotation.swift
//  Stores
//
//  Created by Student on 11/25/24.
//

import Foundation
import MapKit
import Contacts


class StoreAnnotation: NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String? //address
    var logo: String?
    var store: Store?
    
    
    
    init(latitude: CLLocationDegrees, longitude: CLLocationDegrees, title: String, subtitle: String, logo: String?, store: Store?) {
        self.coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        self.title = title
        self.subtitle = subtitle
        self.logo = logo
        self.store = store
    }
    
    
    func mapItem() -> MKMapItem {
        //let destinationTitle = title ?? "Unknown Store"
        let addrDict = [CNPostalAddressCityKey: subtitle ?? ""]
        let placemark = MKPlacemark(coordinate: coordinate, addressDictionary: addrDict)
        let mapItem = MKMapItem(placemark: placemark)
        return mapItem
    }
}
