//
//  Posts.swift
//  Stores
//
//  Created by Student on 12/2/24.
//

import Foundation
import Firebase
import FirebaseDatabase

struct Post {
    var ref: DatabaseReference?
    var id: String
    var postedBy: String
    var date: Date
    var message: String
    
    init(id: String, postedBy: String, date: Date, message: String) {
        self.ref = nil
        self.id = id
        self.postedBy = postedBy
        self.date = date
        self.message = message
    }

    init?(snapshot: DataSnapshot) {
        guard let value = snapshot.value as? [String: Any] else {
            print("Error: Snapshot value is not a dictionary")
            return nil
        }
        
        print("Firebase Data: \(value)")
        
        guard
            let id = value["id"] as? String,
            let postedBy = value["postedBy"] as? String,
            let datePostedString = value["date"] as? String,
            let message = value["message"] as? String
        else {
            print("Error: Missing or malformed data in snapshot. \(value)")
            return nil
        }
        
        self.ref = snapshot.ref
        self.id = id
        self.postedBy = postedBy
        
        
        let dateFormatter: DateFormatter = {
            let formatter = DateFormatter()
            formatter.dateFormat = "MM-dd-yyyy" // format in Firebase
            return formatter
        }()
        
        print("Attempting to parse date: \(datePostedString)")
        
        if let date = dateFormatter.date(from: datePostedString) {
            self.date = date
        } else {
            
            print("Error: Unable to parse date: \(datePostedString). Trying alternative format.")
            let fallbackFormatter = DateFormatter()
            fallbackFormatter.dateFormat = "yyyy-MM-dd"
            
            if let fallbackDate = fallbackFormatter.date(from: datePostedString) {
                self.date = fallbackDate
            } else {
                print("Error: Unable to parse date with fallback format.")
                return nil
            }
        }

        self.message = message
    }

    func toAnyObject() -> [String: Any] {
        let dateFormatter: DateFormatter = {
            let formatter = DateFormatter()
            formatter.dateFormat = "MM-dd-yyyy" // format in Firebase
            return formatter
        }()
        
        let dateString = dateFormatter.string(from: date)
        
        return [
            "id": id,
            "postedBy": postedBy,
            "date": dateString,
            "message": message
        ]
    }
}

