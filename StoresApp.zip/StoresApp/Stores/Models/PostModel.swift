//
//  PostModel.swift
//  Stores
//
//  Created by Student on 12/2/24.
//

import Foundation
import Firebase
import FirebaseDatabase

class PostsModel {
    
    static let shared = PostsModel()
    
    let postsNotification = Notification.Name(rawValue: "postsNotificationKey")
    
    var postedPosts: [Post] = []
    
    let nc = NotificationCenter.default
    
    let postsDBref = Database.database().reference(withPath: "Posts")
    
    var postObserverHandle: UInt?
    
    
    func observePosts() {
        
        postsDBref.observe(.value, with: { snapshot in
            
            var tempPosts: [Post] = []
            
            guard snapshot.exists() else {
                print("Snapshot does not exist")
                return
            }
            
            for child in snapshot.children {
                if let data = child as? DataSnapshot {
                    
                    if let aPost = Post(snapshot: data) {
                        tempPosts.append(aPost)
                        //print("Added Post: \(aPost)")
                    } else {
                        print("Cannot parse Post: \(data)")
                    }
                }
            }
            
            tempPosts.sort {(post1, post2) -> Bool in
                return post1.date > post2.date
            }

            DispatchQueue.main.async {
                self.postedPosts = tempPosts
                //print("Updated postedPosts: \(self.postedPosts)")

                NotificationCenter.default.post(name: self.postsNotification, object: nil)
            }
        })
    }
    
    
    func cancelObserver() {
        if let observerHandle = postObserverHandle {
            postsDBref.removeObserver(withHandle: observerHandle)
        }
    }
    
    
    func postNewPost(post: Post) {
        let newPostRef = postsDBref.child(post.id)
        newPostRef.setValue(post.toAnyObject())
    }
    
    
    func updatePost(post: Post) {
        let postRef = postsDBref.child(post.id)
        postRef.setValue(post.toAnyObject())
    }
    
    
    func deletePost(post: Post) {
        let postRef = postsDBref.child(post.id)
        postRef.removeValue()
    }
}
