//
//  StoresModel.swift
//  Stores
//
//  Created by Student on 11/25/24.
//

import Foundation
import Firebase
import FirebaseDatabase

struct Store {
    var ref: DatabaseReference?
    var id: String
    let name: String
    let address: String
    let hours: String
    let latitude: Double
    let longitude: Double
    
    
    
    init(id: String, name: String, address: String, hours: String, latitude: Double, longitude: Double) {
        self.ref = nil
        self.id = id
        self.name = name
        self.address = address
        self.hours = hours
        self.latitude = latitude
        self.longitude = longitude
        
    }
    
    
    
    
    
    init?(snapshot: DataSnapshot) {
        
        self.id = snapshot.key
        
//        //print("Raw Snapshot Value: \(snapshot.value ?? "nil")")
        
        guard let value = snapshot.value as? [String: Any],
              let name = value["name"] as? String,
              let address = value["address"] as? String,
              let hours = value["hours"] as? String,
              let coordinates = value["coordinates"] as? [String: Double],
              let latitude = coordinates["latitude"],
              let longitude = coordinates["longitude"]
        
        
        else {
            return nil
        }
        
        
        
        //print("Parsed store: \(name), \(address), \(hours), lat: \(latitude), long: \(longitude)") 
   
        self.ref = snapshot.ref
        self.name = name
        self.address = address
        self.hours = hours
        self.latitude = latitude
        self.longitude = longitude
    }
    
    
    func toAnyObject() -> [String: Any] {
        return [
            "name": name,
            "address": address,
            "hours": hours,
            "coordinates": [
                "latitude": latitude,
                "longitude": longitude
            ]
        ]
    }
}
