//
//  StoreModel.swift
//  Stores
//
//  Created by Student on 11/25/24.
//

import Foundation
import Firebase
import FirebaseDatabase

class StoreModel {
    
    static let shared = StoreModel()
    
    let storesNotification = Notification.Name(rawValue: "storesNotificationKey")
    
    var postedStores: [Store] = []
    
    let nc = NotificationCenter.default
    
    let storeDBref = Database.database().reference(withPath: "stores")
    
    var storeObserverHandle: UInt?
    
    let possibleStoreNames = [
        "Adidas Outlet Store", "Aeropostale", "American Eagle", "Ann Taylor Factory Store",
        "Appliances 4 Less", "Banana Republic Factory Store", "Bath and Body Works", "Brooks Brothers Factory Store",
        "Calvin Klein", "Carter's", "Casual Male XL", "Champion", "Chicos Off The Rack", "Clarks", "Coach Outlet",
        "Columbia", "The Cosmetics Company Store", "Crate and Barrel", "ECCO", "Famous Footwear Outlet", "Gap Factory",
        "GUESS Factory", "HANESbrands", "It's All Leggings", "J.Crew Factory", "Jockey", "Kate Spade New York Outlet",
        "Levi's Outlet Store", "Linked Local", "LOFT Outlet", "Lucky Brand Jeans", "Nautica", "NIKE Factory Store",
        "NU2U Consignment Fashions", "Perfuroma", "Polo Ralph Lauren", "PUMA Outlet", "Quails", "Rally House", "Reebok Outlet",
        "Shattered Screens", "Skechers", "Sunglass Hut", "Talbots Outlet", "The Children’s Place", "Timberland Outlet",
        "Tommy Hilfiger", "Under Armour Factory House", "The Uniform Outlet", "Yankee Candle", "Zales Outlet", "Zumiez"
    ]
    
    
    func observeStores() {
        //print("Store DB Ref: \(storeDBref)")
        
        storeDBref.observe(.value, with: { snapshot in
            
            var tempStores: [Store] = []
            
            
            if snapshot.value != nil {
                //print("Firebase Snapshot Value: \(snapshotValue)")
            } else {
                print("Snapshot is empty or does not exist")
            }
            
            guard snapshot.exists() else {
                print("Snapshot does not exist at the path.")
                return
            }
            
            
            for child in snapshot.children {
                if let data = child as? DataSnapshot {
                    //print("Child Snapshot: \(data)")
                    
                    if let store = Store(snapshot: data) {
                        tempStores.append(store)
                        //print("Parsed Store: \(store.name)")
                    } else {
                        print("Cannot parse store data from snapshot: \(data)")
                    }
                }
            }
            
            if tempStores.isEmpty {
                print("No stores were parsed from the snapshot.")
            }
            
            tempStores.sort { $0.name < $1.name }
            
            DispatchQueue.main.async {
                self.postedStores = tempStores
                //print("Updated postedStores array: \(self.postedStores)")
                NotificationCenter.default.post(name: self.storesNotification, object: nil)
            }
        })
    }
    
    
    
    func cancelObserver() {
        storeDBref.removeAllObservers()
    }
    
    
    
    func testFirebaseConnection() {
        storeDBref.getData { error, snapshot in
            if let error = error {
                print("Error fetching data: \(error.localizedDescription)")
            } else if ((snapshot?.exists()) != nil) {
                //print("Data fetched successfully: \(snapshot?.value ?? "No data found")")
            } else {
                print("No data found.")
            }
        }
    }
    
    
    
    
    
    
    func getImage(for store: Store) -> UIImage {
        
        let genericImage = UIImage(named: "genericStoreLogo") ?? UIImage()
        
        var storeName = store.name.lowercased()
        storeName = storeName.replacingOccurrences(of: "’", with: "")
        
        
        //print("Looking for image: \(normalizedStoreName)")
        
        
        if let storeImage = UIImage(named: storeName) {
            //print("Found image for store: \(normalizedStoreName)")
            
            
            let resizedImage = storeImage.scalePreservingAspectRatio(targetSize: CGSize(width: 180.0, height: 180.0))
            return resizedImage
        }
        
        
        //print("Image not found for store: \(normalizedStoreName)")
        return genericImage
    }
    
    
    func getLogoName(for store: Store) -> String {
        let genericLogo = "genericLogo"
        
        let lowercasedName = store.name.lowercased()
        
        for storeName in possibleStoreNames {
            if lowercasedName.contains(storeName) {
                return storeName
            }
        }
        return genericLogo
    }
    
    
    
    func fetchStore(byID storeID: String) async throws -> Store? {
        let storeRef = Database.database().reference().child("Stores").child(storeID)
        
        do {
            let snapshot = try await storeRef.getData()
            
            if let storeData = snapshot.value as? [String: Any] {
                
                print("Fetched store data: \(storeData)")
                
                return Store(snapshot: snapshot)
            } else {
                print("No store found with ID: \(storeID)")
                return nil
            }
        } catch {
            print("Error fetching store with ID \(storeID): \(error.localizedDescription)")
            throw error
        }
    }
}

    extension UIImage {
        
        func scalePreservingAspectRatio(targetSize: CGSize) -> UIImage {
            let widthRatio = targetSize.width / size.width
            let heightRatio = targetSize.height / size.height
            let scaleFactor = min(widthRatio, heightRatio)
            
            let scaledImageSize = CGSize(
                width: size.width * scaleFactor,
                height: size.height * scaleFactor
            )
            
            let renderer = UIGraphicsImageRenderer(size: scaledImageSize)
            let scaledImage = renderer.image { _ in
                self.draw(in: CGRect(origin: .zero, size: scaledImageSize))
            }
            
            return scaledImage
        }
    }

    
