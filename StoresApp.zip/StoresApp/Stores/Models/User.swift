//
//  User.swift
//  Stores
//
//  Created by Student on 11/25/24.
//


import Foundation
import Firebase
import FirebaseDatabase

struct User {
    let ref: DatabaseReference?
    let uid: String
    let email: String
    let profileName: String
    var favoriteStores: [String: Bool]

    init(uid: String, profileName: String, email: String, favoriteStores: [String: Bool] = [:]) {
        self.ref = nil
        self.uid = uid
        self.profileName = profileName
        self.email = email
        self.favoriteStores = favoriteStores
    }

    init?(snapshot: DataSnapshot) {
        guard
            let value = snapshot.value as? [String: AnyObject],
            let profileName = value["profileName"] as? String,
            let email = value["email"] as? String,
            let uid = value["uid"] as? String,
            let favoriteStores = value["favorites"] as? [String: Bool] 
        else {
            return nil
        }

        self.ref = snapshot.ref
        self.uid = uid
        self.profileName = profileName
        self.email = email
        self.favoriteStores = favoriteStores
    }

    func toAnyObject() -> [String: Any] {
        return [
            "uid": uid,
            "profileName": profileName,
            "email": email,
            "favorites": favoriteStores
        ]
    }
}

