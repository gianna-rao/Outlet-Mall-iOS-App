//
//  UserModel.swift
//  Stores
//
//  Created by Student on 11/25/24.
//


import Foundation
import FirebaseAuth
import FirebaseDatabase

class UserModel {
    
    static let shared = UserModel()
    
    let usersUpdatedNotification = Notification.Name(rawValue: "usersListUpdatedKey")
    let onlineUsersUpdatedNotification = Notification.Name(rawValue: "onlineUsersListUpdatedKey")
    
    var authorizedUser: AuthenticatedUser?
    var currentUser: User?
    
    var users: [User] = []
    var onlineUsers: [String] = []
    
    private init() {}
    
    func signInAsync(withEmail email: String, andPassword pw: String) async throws -> (Bool, String) {
        do {
            let authData = try await Auth.auth().signIn(withEmail: email, password: pw)
            authorizedUser = AuthenticatedUser(uid: authData.user.uid, email: authData.user.email!)
            try await getLoggedInUser()
            
            setUserOnline(uid: authData.user.uid, username: authData.user.displayName ?? authData.user.email!)
            
            return (true, "Sign-in Successful")
        } catch {
            return (false, error.localizedDescription)
        }
    }
    
    
    
    func signOut() {
        
        do {
            if let uid = currentUser?.uid {
                offlineUser(uid: uid)
            }
            try Auth.auth().signOut()
            //print("User signed out successfully.")
        } catch let signOutError as NSError {
            print("Error signing out: %@", signOutError)
        }
        
        
        
    }
        
        func registerAsync(withEmail email: String, password pw: String, andProfileName name: String) async throws -> (Bool, String) {
            do {
                let userCreateResponse = try await Auth.auth().createUser(withEmail: email, password: pw)
                authorizedUser = AuthenticatedUser(uid: userCreateResponse.user.uid, email: userCreateResponse.user.email!)
                newRegisteredUser(withUid: authorizedUser!.uid, profileName: name, andEmail: email)
                return (true, "User info Registered")
            } catch {
                return (false, error.localizedDescription)
            }
        }
        
        
        func newRegisteredUser(withUid uid: String, profileName name: String, andEmail email: String) {
            let userDBRef = Database.database().reference(withPath: "Users")
            let user = User(uid: uid, profileName: name, email: email)
            let userNodeRef = userDBRef.child(user.uid)
            
            userNodeRef.setValue(user.toAnyObject())
        }
        
        
        func offlineUser(uid: String) {
            
            let onlineDBRef = Database.database().reference(withPath: "Online")
                
                
            onlineDBRef.child(uid).removeValue { error, _ in
                if let error = error {
                    print("Error removing user from Online: \(error.localizedDescription)")
                } else {
                    //print("User removed from Online successfully.")
                }
            }
        }
        
        
        func listRegisteredUsers() async throws {
            let userDBRef = Database.database().reference(withPath: "Users")
            users.removeAll()
            
            do {
                let snapshot = try await userDBRef.getData()
                for child in snapshot.children {
                    if let userData = child as? DataSnapshot, let anUser = User(snapshot: userData) {
                        users.append(anUser)
                    }
                }
            } catch {
                print("Cannot get users")
            }
        }
        
        
        func observeUsers() {
            let userDBRef = Database.database().reference(withPath: "Users")
            
            userDBRef.observe(.value, with: { snapshot in
                var tempUsers: [User] = []
                for child in snapshot.children {
                    if let data = child as? DataSnapshot, let anUser = User(snapshot: data) {
                        tempUsers.append(anUser)
                    }
                }
                self.users = tempUsers
                NotificationCenter.default.post(name: self.usersUpdatedNotification, object: nil)
            })
        }
        
        
        func getLoggedInUser() async throws {
            guard let uid = authorizedUser?.uid else { return }
            let userDBRef = Database.database().reference()
            
            let userData = try await userDBRef.child("Users/\(uid)").getData()
            currentUser = User(snapshot: userData)
        }
        
        
        func observeOnlineUsers() {
            let onlineDBRef = Database.database().reference(withPath: "Online")
            
            onlineDBRef.observe(.value, with: { snapshot in
                var tempOnlineUsers: [String] = []
                for child in snapshot.children {
                    if let data = child as? DataSnapshot, let name = data.value as? String {
                        tempOnlineUsers.append(name)
                    }
                }
                self.onlineUsers = tempOnlineUsers
                NotificationCenter.default.post(name: self.onlineUsersUpdatedNotification, object: nil)
            })
        }
        
        
    
    func setUserOnline(uid: String, username: String) {
        let onlineDBRef = Database.database().reference(withPath: "Online")
        onlineDBRef.child(uid).setValue(username)
    }


    func fetchFavoriteStores() async throws -> [String] {
        guard let user = Auth.auth().currentUser else {
            throw NSError(domain: "UserModel", code: 1001, userInfo: [NSLocalizedDescriptionKey: "No current user"])
        }

        let userId = user.uid
        let databaseRef = Database.database().reference().child("Users").child(userId).child("favorites")
        
        do {
            
            let snapshot = try await databaseRef.getData()
            
            if let favoritesData = snapshot.value as? [String: Bool] {
                
                let storeNames = Array(favoritesData.keys)
                print("Favorite stores: \(storeNames)")
                return storeNames
            } else {
                print("No favorite stores found for user \(user.uid).")
                return []
            }
        } catch {
            print("Error fetching favorite stores: \(error.localizedDescription)")
            throw error
        }
    }
    
    

    
    func getStoreNames(from storeIDs: [String]) async throws -> [String] {
        var storeNames: [String] = []

        
        try await withThrowingTaskGroup(of: (String, Error?).self) { group in
            for storeID in storeIDs {
                group.addTask {
                    do {
                        
                        if let store = try await StoreModel.shared.fetchStore(byID: storeID) {
                            return (store.name, nil)
                        } else {
                            return ("Unknown Store", nil)
                        }
                    } catch {
                        return ("", error)
                    }
                }
            }
            
            
            for try await (storeName, error) in group {
                if let error = error {
                    print("Error fetching store: \(error.localizedDescription)")
                } else {
                    storeNames.append(storeName)
                }
            }
        }

        return storeNames
    }
    
    
}

