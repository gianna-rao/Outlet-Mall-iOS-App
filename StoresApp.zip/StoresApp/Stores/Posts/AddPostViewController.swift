//
//  AddPostViewController.swift
//  Stores
//
//  Created by Student on 12/2/24.
//

import UIKit
import FirebaseAuth
import FirebaseDatabase

class AddPostViewController: UIViewController {
    
    // MARK: - Outlets
    
    @IBOutlet weak var textViewMessage: UITextView!
    
    // MARK: - Variables
    var post: Post?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let post = post {
            textViewMessage.text = post.message
        }
    }

    // MARK: - Actions
    @IBAction func saveNewPost(_ sender: Any) {
        
        guard let message = textViewMessage.text, !message.isEmpty else {
            let alert = UIAlertController(title: "Error", message: "Message cannot be empty.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
            return
        }
        
        getCurrentUserProfileName { [weak self] profileName in
            guard let self = self else { return }
            
            let newPost = Post(id: UUID().uuidString, postedBy: profileName, date: Date(), message: message)
            
            PostsModel.shared.postNewPost(post: newPost)
            
            self.navigationController?.popViewController(animated: true)
        }
    }

    // MARK: - Helper Methods
    
    func getCurrentUserProfileName(completion: @escaping (String) -> Void) {
        guard let userId = Auth.auth().currentUser?.uid else {
            completion("Anonymous")
            return
        }
        
        let usersRef = Database.database().reference().child("Users").child(userId)
        
        usersRef.observeSingleEvent(of: .value) { snapshot in
            if let value = snapshot.value as? [String: Any],
               let profileName = value["profileName"] as? String {
                completion(profileName)
            } else {
                completion("Anonymous")
            }
        }
    }
}
