//
//  PostTableViewCell.swift
//  Stores
//
//  Created by Student on 12/2/24.
//


import UIKit

class PostTableViewCell: UITableViewCell {
    
    
    
    @IBOutlet weak var postedBy: UILabel!
    
    @IBOutlet weak var message: UILabel!
    
    @IBOutlet weak var date: UILabel!
  
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        
    }
    
    
    
}
