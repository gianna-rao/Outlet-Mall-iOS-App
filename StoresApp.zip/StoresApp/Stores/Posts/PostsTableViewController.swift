//
//  PostsTableViewController.swift
//  Stores
//
//  Created by Student on 12/2/24.
//

import UIKit
import AVFAudio

class PostsTableViewController: UITableViewController, AVSpeechSynthesizerDelegate {
    
    let postsNotification = Notification.Name(rawValue: "postsNotificationKey")
    
    let postsModel = PostsModel.shared
    let userModel = UserModel.shared
    
    
    let speechSynthesizer = AVSpeechSynthesizer()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Posts"
        
        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addNewPost))
        navigationItem.rightBarButtonItem = addButton
        
        
        postsModel.observePosts()
        createObservers()
        
        speechSynthesizer.delegate = self
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationItem.hidesBackButton = true
        
        
    }
    
    
    
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    func createObservers() {
        NotificationCenter.default.addObserver(self, selector: #selector(refreshTable(notification:)), name: postsNotification, object: nil)
    }
    
    @objc func refreshTable(notification: NSNotification) {
        self.tableView.reloadData()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return postsModel.postedPosts.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "postsCell", for: indexPath) as? PostTableViewCell else {
                    return UITableViewCell()
                }
                
                let post = postsModel.postedPosts[indexPath.row]
        
                for subview in cell.contentView.subviews {
                    if let button = subview as? UIButton {
                        button.removeFromSuperview()
                    }
                }

                
                let soundButton = UIButton(type: .system)
                soundButton.setImage(UIImage(systemName: "play.fill"), for: .normal)
                soundButton.frame = CGRect(x: 10, y: 10, width: 25, height: 25)
                    
                soundButton.tintColor = .black
                soundButton.addTarget(self, action: #selector(readPostMessageButtonTapped(sender:)), for: .touchUpInside)
                soundButton.tag = indexPath.row
                
                cell.contentView.addSubview(soundButton)
                
                cell.message.text = post.message
                cell.postedBy.text = post.postedBy
                
                let dateFormatter: DateFormatter = {
                    let formatter = DateFormatter()
                    formatter.dateFormat = "MM-dd-yyyy"
                    return formatter
                }()
                
                cell.date.text = dateFormatter.string(from: post.date)
                
                return cell
    }
        
       

         

           

    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showAddPost" {
            if let postVC = segue.destination as? AddPostViewController {
                postVC.post = nil  
            }
        }
    }
    
    @objc func addNewPost() {
        performSegue(withIdentifier: "showAddPost", sender: self)
    }
    
    func readPostMessage(post: Post, button: UIButton) {
            let message = post.message
            
            let utterance = AVSpeechUtterance(string: message)
            
            utterance.rate = AVSpeechUtteranceDefaultSpeechRate
            utterance.pitchMultiplier = 1.0
            
            if speechSynthesizer.isSpeaking {
                
                speechSynthesizer.stopSpeaking(at: .immediate)
                button.setImage(UIImage(systemName: "play.fill"), for: .normal)
                
            } else {
                
                speechSynthesizer.speak(utterance)
                button.setImage(UIImage(systemName: "stop.fill"), for: .normal)
            }
        }
        
        // MARK: - Button Action for Text-to-Speech
        @objc func readPostMessageButtonTapped(sender: UIButton) {
            
            let postIndex = sender.tag
            let selectedPost = postsModel.postedPosts[postIndex]
            
            readPostMessage(post: selectedPost, button: sender)
        }
    
    
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        
            if let visibleCells = tableView.visibleCells as? [PostTableViewCell] {
                for (index, cell) in visibleCells.enumerated() {
                    if let soundButton = cell.contentView.subviews.compactMap({ $0 as? UIButton }).first {
                        
                        soundButton.setImage(UIImage(systemName: "play.fill"), for: .normal)
                    }
                }
            }
        }
            
    
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let post = postsModel.postedPosts[indexPath.row]
        
        let baseHeight: CGFloat = 100
        let additionalHeight = CGFloat(post.message.count / 40) * 20
        
        return baseHeight + additionalHeight
        
    }
}
  

