//
//  LoginViewController.swift
//  Stores
//
//  Created by Student on 11/25/24.
//

import UIKit

class LoginViewController: UIViewController {
    
    let userModel = UserModel.shared
    let storesModel = StoreModel.shared
    
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        storesModel.observeStores()
    }
    
    
    @IBAction func signIn(_ sender: Any) {
        
        login()
        
    }
    
    func login () {
        
        Task {
            if let enteredEmail = email.text, let enteredPassword = password.text {
                let (result, resultMessage) = try await userModel.signInAsync(withEmail: enteredEmail, andPassword: enteredPassword)
                if result {
                    performSegue(withIdentifier: "mainSegue", sender: self)
                } else {
                    let alert = UIAlertController(title: "Invalid Login",
                                                  message: resultMessage,
                                                  preferredStyle: .alert)
                    
                    alert.addAction(UIAlertAction(title: "OK", style: .default))
                    
                    self.present(alert, animated: true, completion: nil)
                }
            } else {
                let alert = UIAlertController(title: "Login",
                                              message: "Enter Credentials",
                                              preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                
                self.present(alert, animated: true, completion: nil)
            }
            
        }
    }
    
       
}
