//
//  RegisterViewController.swift
//  Stores
//
//  Created by Student on 11/25/24.
//


import UIKit

class RegisterViewController: UIViewController {
    let userModel = UserModel.shared
    
    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    
        
       
    @IBAction func signUp(_ sender: Any) {
        
        if let enteredProfileName = name.text,
               let enteredEmail = email.text,
               let enteredPassword = password.text {
                
                Task {
                    let (result, resultMessage) = try await userModel.registerAsync(withEmail: enteredEmail, password: enteredPassword, andProfileName: enteredProfileName)
                    if result {
                        
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        if let loginVC = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController {
                            self.navigationController?.popToRootViewController(animated: false) 
                            self.navigationController?.pushViewController(loginVC, animated: true)
                        } else {
                            print("Error with LoginViewController")
                        }
                    } else {
                        let alert = UIAlertController(title: "Invalid Registration",
                                                      message: resultMessage,
                                                      preferredStyle: .alert)
                        
                        alert.addAction(UIAlertAction(title: "OK", style: .default))
                        
                        self.present(alert, animated: true, completion: nil)
                    }
                }
                
            } else {
                let alert = UIAlertController(title: "Register",
                                              message: "Enter Credentials",
                                              preferredStyle: .alert)
                
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                
                self.present(alert, animated: true, completion: nil)
            }
    }
    

    @IBAction func backToLogin(_ sender: Any) {
        
        self.dismiss(animated: true)
    }
     

}

